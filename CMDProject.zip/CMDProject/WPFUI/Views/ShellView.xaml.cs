﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using WPFUI.Models;
using WPFUI.ViewModels;

namespace WPFUI.Views
{
    /// <summary>
    /// Logique d'interaction pour ShellView.xaml
    /// </summary>
    public partial class ShellView : Window
    {
        private MediaPlayer mediaPlayer;
        private ShellViewModel viewModel;



        public ShellView()
        {
            InitializeComponent();
            mediaPlayer = new MediaPlayer();
        }

        private void Hide_Click(object sender, RoutedEventArgs e)
        {
            ActiveItem.Visibility = Visibility.Collapsed;
            AllPlaylist.Visibility = Visibility.Collapsed;
            GetAllPlaylistMusic.Visibility = Visibility.Collapsed;
        }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            ActiveItem.Visibility = Visibility.Visible;
            AllPlaylist.Visibility = Visibility.Collapsed;
            GetAllPlaylistMusic.Visibility = Visibility.Collapsed;
        }

        private void ShowPlaylist_Click(object sender, RoutedEventArgs e)
        {
            ActiveItem.Visibility = Visibility.Collapsed;
            GetAllPlaylistMusic.Visibility = Visibility.Collapsed;
            AllPlaylist.Visibility = Visibility.Visible;

            ShellViewModel viewModel = new ShellViewModel();
            getAllPlaylist.ItemsSource = viewModel.playlist;
        }

        private void SelectPlaylistName_Click(object sender, RoutedEventArgs e)
        {
            var item = (sender as ListView).SelectedItem;
            PlaylistModel getSelection = (PlaylistModel)item;

            ActiveItem.Visibility = Visibility.Collapsed;
            AllPlaylist.Visibility = Visibility.Collapsed;

            viewModel = new ShellViewModel();

            viewModel.GetAllPlayListMusic(getSelection.Name);

            CurrentPlaylist.Text = getSelection.Name;
            getAllPlaylistMusic.ItemsSource = viewModel.playlistMusic;

            GetAllPlaylistMusic.Visibility = Visibility.Visible;

        }

        private void ShowPlayListMusic_Click(object sender, EventArgs e)
        {
            ActiveItem.Visibility = Visibility.Collapsed;
            AllPlaylist.Visibility = Visibility.Collapsed;
            GetAllPlaylistMusic.Visibility = Visibility.Visible;

        }

        private void SelectMusicName_Click(object sender, RoutedEventArgs e)
        {
            ActiveItem.Visibility = Visibility.Collapsed;
            AllPlaylist.Visibility = Visibility.Collapsed;

            var item = (sender as ListView).SelectedItem;
            MusicModel getSelection = (MusicModel)item;

            CurrentMedia.Source = new Uri(getSelection.Path);
            CurrentMedia.Play();
            CurrentName.Text = getSelection.Name;

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += timer_Tick;
            timer.Start();

            pauseButton.Visibility = Visibility.Visible;
            playButton.Visibility = Visibility.Collapsed;
            GetAllPlaylistMusic.Visibility = Visibility.Collapsed;

        }

        void timer_Tick(object sender, EventArgs e)
        {
            if (CurrentMedia.Source != null)
            {
                try
                {
                    lblStatus.Content = String.Format("{0} / {1}", CurrentMedia.Position.ToString(@"mm\:ss"), CurrentMedia.NaturalDuration.TimeSpan.ToString(@"mm\:ss"));
                }
                catch
                {
                    Console.WriteLine("");
                }
            }
            else
            {
                lblStatus.Content = "No file selected...";
            }
        }


        private void SelectFiles_Click(object sender, RoutedEventArgs e)
        {

            // Create OpenFileDialog 
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            // Set filter for file extension and default file extension 
            dlg.Filter = "MP4 Files (*.mp4)|*.mp4|AVI Files (*.avi)|*.avi|MKV Files (*.mkv)|*.mkv|FLV Files (*.flv)|*.flv|FLAC Files(*.flac)| *.flac|MPF3 Files(*.mp3) |*.mp3|WAV Files(*.wav) |*.wav";
            Nullable<bool> result = dlg.ShowDialog();
            ShellViewModel viewModel = new ShellViewModel();

            if (result == true)
            {

                string filename = dlg.FileName;
                var found = filename.LastIndexOf("\\");
                var getFilename = filename.Substring(found + 1);
                // Open document 
                if (File.Exists($"C:/Users/projet/playlist/{CurrentPlaylist.Text}/{getFilename}") == false)
                {
                    File.Copy(filename, $"C:/Users/projet/playlist/{CurrentPlaylist.Text}/{getFilename}");

                }
            }

        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {

            CurrentMedia.Play();
            pauseButton.Visibility = Visibility.Visible;
            playButton.Visibility = Visibility.Collapsed;

            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += timer_Tick;
            timer.Start();
        }

        private void btnPause_Click(object sender, RoutedEventArgs e)
        {

            CurrentMedia.Pause();
            playButton.Visibility = Visibility.Visible;
            pauseButton.Visibility = Visibility.Collapsed;

        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {

            CurrentMedia.Stop();

        }

        private void ChangeMediaVolume(object sender, RoutedPropertyChangedEventArgs<double> args)
        {
            CurrentMedia.Volume = (double)volumeSlider.Value;
        }

        private void SeekToMediaPosition(object sender, RoutedPropertyChangedEventArgs<double> args)
        {
            var slider = sender as Slider;
            // ... Get Value.
            double value = slider.Value;
        }

        
    }
}