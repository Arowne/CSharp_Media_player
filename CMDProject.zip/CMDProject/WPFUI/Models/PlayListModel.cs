﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFUI.Models
{
    public class PlaylistModel
    {
        public string Name {
            get;
            set;
        }
    }
}
