﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Controls;
using Caliburn.Micro;
using WPFUI.Models;
using WPFUI.ViewModels.Commands.WPFUI.ViewModels.Commands;

namespace WPFUI.ViewModels
{

    public class ShellViewModel : Conductor<object>
    {
        private string _playListName;
        private string _selectedMusic;
        private ObservableCollection<PlaylistModel>  _playlist;
        private ObservableCollection<MusicModel> _playlistMusic;

        public string selectedMusic
        {
            get
            {
                return _selectedMusic;
            }
            set
            {
                _selectedMusic = value;
                NotifyOfPropertyChange(() => selectedMusic);
            }
        }

        public ObservableCollection<PlaylistModel> playlist
        {
            get
            {
                return _playlist;
            }
            set
            {
                _playlist = value;
                NotifyOfPropertyChange(() => playlist);
            }
        }

        public ObservableCollection<MusicModel> playlistMusic
        {
            get
            {
                return _playlistMusic;
            }
            set
            {
                _playlistMusic = value;
                NotifyOfPropertyChange(() => playlistMusic);
            }
        }

        public ReadPlaylistCommand ReadPlaylistCommand { get; set; }
        private string _playlistDir = "C:/Users/projet/playlist/";

        public string PlayListName
        {
            get
            {
                return _playListName;
            }
            set
            {
                _playListName = value;
                NotifyOfPropertyChange(() => PlayListName);
            }
        }


        public void CreatePlayList(string name)
        {
            // Specify the directory you want to manipulate.
            try
            {
                // Try to create the directory.
                DirectoryInfo di = Directory.CreateDirectory(_playlistDir + name);

            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
                new ExceptionValidationRule();
            }
            finally { }
        }


        public ShellViewModel()
        {
            ReadPlaylistCommand = new ReadPlaylistCommand(this);
            var library = new FirstChildViewModel();
            ActivateItem(library);
            playlist = new ObservableCollection<PlaylistModel>();
            playlistMusic = new ObservableCollection<MusicModel>();
            GetAllPlayList();
        }

        public bool AddPlayList()
        {
            return true;
        }

        public void GetAllPlayList()
        {
            try
            {

                foreach (var list in playlist)
                {
                    playlist.Remove(list);
                }

                string[] dirs = Directory.GetDirectories(_playlistDir, "*", SearchOption.TopDirectoryOnly);

                foreach (string dir in dirs)
                {

                    var found = dir.LastIndexOf("/");
                    var dirName = dir.Substring(found + 1);

                    PlaylistModel newPlayList = new PlaylistModel() { Name = dirName };
                    playlist.Add(newPlayList);

                }

            }
            catch
            {
                Console.WriteLine("");
            }
        }

        public void GetAllPlayListMusic(string name)
        {
                string[] files = Directory.GetFiles(_playlistDir + name, "*", SearchOption.TopDirectoryOnly);

                foreach (string file in files)
                {
                    Console.WriteLine((string)file);
                    var found = file.LastIndexOf("/");
                    var fileName = file.Substring(found + 1);

                    MusicModel newPlayListMusic = new MusicModel() { Path = file, Name = fileName };
                    playlistMusic.Add(newPlayListMusic);

                }

        }

        public void ReadPlayList()
        {

        }


    }
}










