﻿using System;
using Caliburn.Micro;
using WPFUI.Models;

namespace WPFUI.ViewModels
{
    public class ShellViewModel : Conductor<object>
    {
        public int loadPageCounter = 0;
        public string LibraryZindex = "-5000";
        
        public ShellViewModel()
        {
            var library = new FirstChildViewModel();
            ActivateItem(library);
        }

        public bool LoadPageOne()
        {
            loadPageCounter+= 1;


            if (loadPageCounter % 2 != 0)
            {
                ActiveItem.Visibility = Visibilty.Collapsed;
                LibraryZindex = "5000";
                return true;
            }

            LibraryZindex = "-5000";
            return true;
        }
    }
}










