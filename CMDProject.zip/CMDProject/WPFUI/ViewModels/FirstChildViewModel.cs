﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Caliburn.Micro;
using WPFUI.Models;
using WPFUI.ViewModels.Commands;

namespace WPFUI.ViewModels
{
    public class FirstChildViewModel : Conductor<object>
    {

        public ObservableCollection<PlaylistModel> playlist { get; set; }

        public AddPlaylistCommand AddPlaylistCommand { get; set; }
        private string _playlistDir  = "C:/Users/projet/playlist/";


        public FirstChildViewModel()
        {
            AddPlaylistCommand = new AddPlaylistCommand(this);
        }


        public void CreatePlayList(string name)
        {
            // Specify the directory you want to manipulate.
            try
            {
                // Try to create the directory.
                DirectoryInfo di = Directory.CreateDirectory(_playlistDir + name);

            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
                new ExceptionValidationRule();
            }
            finally { }
        }

        public bool AddPlayList()
        {
            return true;
        }


    }
}
